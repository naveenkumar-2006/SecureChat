# Secure Chat Application 🔐

A full-stack real-time chat application with **AES-256 encryption**, built with Django, Django Channels (WebSockets), and a modern dark-themed UI.

## Features

- 🔐 **AES-256-CBC Encryption** — All messages encrypted before database storage
- 💬 **Real-time Messaging** — Instant communication via WebSockets
- 👤 **User Authentication** — Register, login, and logout
- 🏠 **Chat Rooms** — Create and join multiple chat rooms
- 📜 **Chat History** — View previous messages (decrypted in UI)
- 🟢 **Online Status** — See when users join/leave rooms
- 🌙 **Modern Dark UI** — Glassmorphism design with smooth animations
- 📱 **Responsive Design** — Works on desktop and mobile

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Backend | Django 6.0 |
| WebSockets | Django Channels + Daphne |
| Database | MySQL |
| Encryption | PyCryptodome (AES-256-CBC) |
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Font | Inter (Google Fonts) |

## Prerequisites

- Python 3.10+
- MySQL Server running locally
- pip (Python package manager)

## Setup Instructions

### 1. Create MySQL Database

Open MySQL and create the database:

```sql
CREATE DATABASE securechat_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. Configure Database Credentials

Edit `securechat/settings.py` and update the `DATABASES` section with your MySQL credentials:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'securechat_db',
        'USER': 'root',
        'PASSWORD': 'your_password_here',  # Update this
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run Database Migrations

```bash
python manage.py makemigrations chat
python manage.py migrate
```

### 5. Create a Superuser (Optional, for admin panel)

```bash
python manage.py createsuperuser
```

### 6. Run the Development Server

```bash
python manage.py runserver
```

The application will be available at: **http://127.0.0.1:8000/**

## Usage

1. **Register** — Create an account at `/register/`
2. **Login** — Sign in at `/` (homepage)
3. **Create a Room** — In the lobby, create a new chat room
4. **Chat** — Join a room and start sending encrypted messages!
5. **Verify Encryption** — Check the Django admin panel (`/admin/`) to see encrypted messages stored in the database

## How AES Encryption Works

```
 User types message
        │
        ▼
 ┌─────────────────┐
 │  encrypt_message │  ← AES-256-CBC + Random IV
 │  (plaintext)     │
 └────────┬────────┘
          │
          ▼
 ┌─────────────────┐
 │  MySQL Database  │  ← Stores base64(IV + ciphertext)
 │  (encrypted)     │
 └────────┬────────┘
          │
          ▼
 ┌─────────────────┐
 │  decrypt_message │  ← Extracts IV, decrypts with key
 │  (ciphertext)    │
 └────────┬────────┘
          │
          ▼
 Receiver sees plaintext
```

## File Structure

```
Crypto/
├── manage.py                    # Django management script
├── requirements.txt             # Python dependencies
├── README.md                    # This file
├── securechat/                  # Django project settings
│   ├── settings.py             # Configuration (DB, Channels, AES key)
│   ├── urls.py                 # Root URL routing
│   ├── asgi.py                 # ASGI config (HTTP + WebSocket)
│   └── wsgi.py                 # WSGI config
└── chat/                       # Chat application
    ├── models.py               # ChatRoom, Message models
    ├── views.py                # Auth & chat view logic
    ├── urls.py                 # App URL routing
    ├── consumers.py            # WebSocket consumer
    ├── routing.py              # WebSocket URL routing
    ├── encryption.py           # AES encrypt/decrypt functions
    ├── forms.py                # Registration & room forms
    ├── admin.py                # Admin panel config
    ├── templates/chat/         # HTML templates
    │   ├── base.html           # Base layout
    │   ├── login.html          # Login page
    │   ├── register.html       # Registration page
    │   ├── lobby.html          # Room listing
    │   └── room.html           # Chat interface
    └── static/chat/            # Static assets
        ├── css/styles.css      # All styling
        └── js/chat.js          # WebSocket client
```

## Security Notes

- Messages are encrypted with AES-256-CBC before database storage
- Each message uses a unique random Initialization Vector (IV)
- The shared secret key is configured in `settings.py`
- In production, store the key in environment variables
- Django's CSRF protection is enabled for all forms
- WebSocket connections require authentication

## License

This project is for educational purposes.
