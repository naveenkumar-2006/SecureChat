"""
WebSocket consumer for real-time chat messaging.

Handles WebSocket connections for chat rooms:
- Connects users to a channel group for their room
- Receives messages, encrypts them, saves to database
- Broadcasts decrypted messages to all users in the room
"""

import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.conf import settings

from .models import ChatRoom, Message
from .encryption import encrypt_message, decrypt_message


class ChatConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for handling real-time chat messages.
    
    Each chat room has its own channel group. When a user sends a message:
    1. The message is encrypted using AES-256
    2. The encrypted message is saved to the database
    3. The decrypted message is broadcast to all users in the room
    """
    
    async def connect(self):
        """
        Called when a WebSocket connection is opened.
        Adds the user to the room's channel group.
        """
        # Get room name from the URL route
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f'chat_{self.room_name}'
        self.user = self.scope['user']
        
        # Reject connection if user is not authenticated
        if not self.user.is_authenticated:
            await self.close()
            return
        
        # Join the room's channel group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        # Accept the WebSocket connection
        await self.accept()
        
        # Notify the room that a user has joined
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_status',
                'username': self.user.username,
                'status': 'online',
            }
        )
    
    async def disconnect(self, close_code):
        """
        Called when a WebSocket connection is closed.
        Removes the user from the room's channel group.
        """
        # Notify the room that a user has left
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'user_status',
                    'username': self.user.username,
                    'status': 'offline',
                }
            )
            
            # Leave the room's channel group
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )
    
    async def receive(self, text_data):
        """
        Called when a message is received from the WebSocket.
        Handles sending messages, clearing chat, and deleting rooms.
        """
        data = json.loads(text_data)
        action = data.get('action')
        
        if action == 'clear_chat' or action == 'delete_room':
            @database_sync_to_async
            def perform_room_action(act, username):
                try:
                    room = ChatRoom.objects.get(name=self.room_name)
                    # Use username to compare to bypass LazyObject relation synchronous fetch limits
                    if room.created_by.username == username:
                        if act == 'clear_chat':
                            Message.objects.filter(room=room).delete()
                            return True
                        elif act == 'delete_room':
                            room.delete()
                            return True
                except ChatRoom.DoesNotExist:
                    pass
                return False
                
            success = await perform_room_action(action, self.user.username)
            if success:
                if action == 'clear_chat':
                    await self.channel_layer.group_send(self.room_group_name, {'type': 'chat_clear'})
                elif action == 'delete_room':
                    await self.channel_layer.group_send(self.room_group_name, {'type': 'room_deleted'})
            return
        
        message_text = data.get('message', '').strip()
        if not message_text:
            return
        
        # Get the AES encryption key from settings
        aes_key = settings.AES_SECRET_KEY
        
        # Encrypt the message using AES-256-CBC
        encrypted_content = encrypt_message(message_text, aes_key)
        
        # Save the encrypted message to the database
        saved_message = await self.save_message(encrypted_content)
        
        # Broadcast the DECRYPTED message to all users in the room
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': message_text,
                'username': self.user.username,
                'timestamp': saved_message.timestamp.isoformat(),
                'encrypted': encrypted_content,
            }
        )
    
    async def chat_clear(self, event):
        """Handler to tell clients to clear the UI."""
        await self.send(text_data=json.dumps({
            'type': 'clear_chat'
        }))
        
    async def room_deleted(self, event):
        """Handler to tell clients to redirect to lobby."""
        await self.send(text_data=json.dumps({
            'type': 'room_deleted'
        }))
    
    async def chat_message(self, event):
        """
        Handler for 'chat_message' type events.
        Sends the message to the WebSocket client.
        """
        await self.send(text_data=json.dumps({
            'type': 'message',
            'message': event['message'],
            'username': event['username'],
            'timestamp': event['timestamp'],
            'encrypted': event.get('encrypted', ''),
            'message_type': event.get('message_type', 'text'),
            'file_url': event.get('file_url', ''),
            'file_name': event.get('file_name', ''),
            'file_size': event.get('file_size', 0),
        }))
    
    async def user_status(self, event):
        """
        Handler for 'user_status' type events.
        Notifies clients when users join or leave the room.
        """
        await self.send(text_data=json.dumps({
            'type': 'status',
            'username': event['username'],
            'status': event['status'],
        }))
    
    @database_sync_to_async
    def save_message(self, encrypted_content):
        """
        Save an encrypted message to the database.
        
        Args:
            encrypted_content (str): The AES-encrypted message (base64 encoded).
        
        Returns:
            Message: The saved Message model instance.
        """
        room = ChatRoom.objects.get(name=self.room_name)
        message = Message.objects.create(
            room=room,
            sender=self.user,
            encrypted_content=encrypted_content,
        )
        return message
