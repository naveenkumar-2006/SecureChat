"""
URL routing for the chat application.

Maps URLs to view functions for authentication and chat features.
"""

from django.urls import path
from . import views

urlpatterns = [
    # Authentication URLs
    path('', views.landing_view, name='landing'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    
    # Chat URLs
    path('lobby/', views.lobby_view, name='lobby'),
    path('create-room/', views.create_room_view, name='create_room'),
    path('chat/<str:room_name>/', views.room_view, name='room'),
    
    # File API
    path('api/chat/<str:room_name>/upload/', views.upload_file_view, name='upload_file'),
]
