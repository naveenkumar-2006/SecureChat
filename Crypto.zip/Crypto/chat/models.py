"""
Database models for the Secure Chat Application.

ChatRoom: Represents a chat room where users can communicate.
Message: Stores encrypted messages with sender info and timestamps.
"""

from django.db import models
from django.contrib.auth.models import User


class ChatRoom(models.Model):
    """
    Represents a chat room.
    Users join rooms to communicate with each other.
    """
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, default='')
    created_by = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='created_rooms'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name


class Message(models.Model):
    """
    Stores encrypted chat messages.
    
    The 'encrypted_content' field stores AES-256-CBC encrypted text
    as a base64-encoded string. Messages are encrypted before saving
    and decrypted only when displayed to authorized users.
    """
    room = models.ForeignKey(
        ChatRoom, on_delete=models.CASCADE, related_name='messages'
    )
    sender = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='sent_messages'
    )
    MESSAGE_TYPES = (
        ('text', 'Text'),
        ('image', 'Image'),
        ('video', 'Video'),
        ('document', 'Document'),
    )
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPES, default='text')
    
    # This field stores the AES-encrypted text message or file metadata (base64 encoded)
    encrypted_content = models.TextField(default="")
    
    # Static file endpoints (unencrypted on disk to support pure HTML5 native previewing)
    file_url = models.CharField(max_length=500, blank=True, null=True)
    file_name = models.CharField(max_length=255, blank=True, null=True)
    file_size = models.IntegerField(blank=True, null=True) # in bytes
    timestamp = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['timestamp']  # Messages ordered chronologically
    
    def __str__(self):
        return f'{self.sender.username} in {self.room.name} at {self.timestamp}'
