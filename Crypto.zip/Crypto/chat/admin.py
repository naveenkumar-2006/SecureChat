"""
Admin configuration for the chat application.

Registers ChatRoom and Message models with the Django admin site.
"""

from django.contrib import admin
from .models import ChatRoom, Message


class MessageInline(admin.TabularInline):
    """Inline view to see messages directly inside a Room."""
    model = Message
    extra = 0
    readonly_fields = ['sender', 'message_type', 'encrypted_content', 'file_url', 'timestamp']
    can_delete = True

@admin.register(ChatRoom)
class ChatRoomAdmin(admin.ModelAdmin):
    """Admin view for ChatRoom model."""
    list_display = ['name', 'created_by', 'created_at']
    search_fields = ['name', 'created_by__username']
    list_filter = ['created_by']
    inlines = [MessageInline]
    
    def has_delete_permission(self, request, obj=None):
        """Only superusers or the room creator can delete a room from Admin."""
        if request.user.is_superuser:
            return True
        if obj is not None and obj.created_by == request.user:
            return True
        return False
        
    def has_change_permission(self, request, obj=None):
        """Only superusers or the room creator can edit a room from Admin."""
        if request.user.is_superuser:
            return True
        if obj is not None and obj.created_by == request.user:
            return True
        return False

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    """
    Admin view for Message model.
    Shows encrypted content in the admin panel (demonstrating encryption at rest).
    """
    list_display = ['sender', 'room', 'message_type', 'encrypted_content_preview', 'timestamp']
    list_filter = ['room', 'sender', 'message_type']
    search_fields = ['sender__username', 'room__name']
    
    def encrypted_content_preview(self, obj):
        """Show a truncated version of the encrypted content."""
        content = str(obj.encrypted_content) if obj.encrypted_content else ""
        if len(content) > 60:
            return content[:60] + '...'
        return content
    encrypted_content_preview.short_description = 'Encrypted Content'
    
    def has_delete_permission(self, request, obj=None):
        """Only room creators (or superusers) can delete messages belonging to their room in Admin."""
        if request.user.is_superuser:
            return True
        if obj is not None and obj.room.created_by == request.user:
            return True
        return False
