/**
 * Secure Chat Application - WebSocket Client
 * 
 * Handles:
 * - WebSocket connection to Django Channels
 * - Sending and receiving messages
 * - Auto-reconnect on connection loss
 * - Message rendering with timestamps
 * - Auto-scroll to latest message
 */

// ═══════════════════════════════════════════
// DOM Elements
// ═══════════════════════════════════════════
const chatMessages = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const connectionIndicator = document.getElementById('connection-indicator');
const connectionStatus = document.getElementById('connection-status');
const typingIndicator = document.getElementById('typing-indicator');
const statusBar = document.getElementById('chat-status-bar');

// ═══════════════════════════════════════════
// WebSocket Connection
// ═══════════════════════════════════════════

let chatSocket = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
const RECONNECT_DELAY = 2000; // 2 seconds

/**
 * Initialize WebSocket connection to the chat room.
 * Uses ws:// for HTTP and wss:// for HTTPS.
 */
function connectWebSocket() {
    // Determine WebSocket protocol based on page protocol
    const wsProtocol = window.location.protocol === 'https:' ? 'wss://' : 'ws://';
    const wsUrl = wsProtocol + window.location.host + '/ws/chat/' + ROOM_NAME + '/';
    
    console.log('🔌 Connecting to WebSocket:', wsUrl);
    chatSocket = new WebSocket(wsUrl);
    
    // ─── Connection Opened ───
    chatSocket.onopen = function(e) {
        console.log('✅ WebSocket connected');
        reconnectAttempts = 0;
        updateConnectionStatus('connected', 'Connected');
    };
    
    // ─── Message Received ───
    chatSocket.onmessage = function(e) {
        const data = JSON.parse(e.data);
        console.log('📨 Received:', data);
        
        if (data.type === 'message') {
            // Display the decrypted message (or media)
            displayMessage(data.username, data.message, data.timestamp, data.encrypted, data.message_type, data.file_url, data.file_name);
        } else if (data.type === 'status') {
            // Display user status change (online/offline)
            displayStatusMessage(data.username, data.status);
        } else if (data.type === 'clear_chat') {
            // Clear all messages
            chatMessages.innerHTML = '';
            displayStatusMessage('System', 'Chat history has been cleared');
        } else if (data.type === 'room_deleted') {
            // Room deleted, redirect to lobby
            window.location.href = '/lobby/';
        }
    };
    
    // ─── Connection Closed ───
    chatSocket.onclose = function(e) {
        console.log('❌ WebSocket closed:', e.code, e.reason);
        updateConnectionStatus('disconnected', 'Disconnected');
        
        // Auto-reconnect with exponential backoff
        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempts++;
            const delay = RECONNECT_DELAY * reconnectAttempts;
            console.log(`🔄 Reconnecting in ${delay/1000}s (attempt ${reconnectAttempts})...`);
            updateConnectionStatus('disconnected', `Reconnecting (${reconnectAttempts})...`);
            setTimeout(connectWebSocket, delay);
        } else {
            updateConnectionStatus('disconnected', 'Connection lost');
        }
    };
    
    // ─── Connection Error ───
    chatSocket.onerror = function(e) {
        console.error('⚠️ WebSocket error:', e);
        updateConnectionStatus('disconnected', 'Error');
    };
}


// ═══════════════════════════════════════════
// Message Handling
// ═══════════════════════════════════════════

/**
 * Send a message through the WebSocket.
 * The message will be encrypted server-side before storage.
 */
function sendMessage() {
    const message = messageInput.value.trim();
    
    if (!message) return;
    
    if (chatSocket && chatSocket.readyState === WebSocket.OPEN) {
        // Send message as JSON
        chatSocket.send(JSON.stringify({
            'message': message
        }));
        
        // Clear the input field
        messageInput.value = '';
        messageInput.focus();
    } else {
        console.warn('⚠️ WebSocket is not connected');
        updateConnectionStatus('disconnected', 'Not connected');
    }
}

/**
 * Display a chat message in the messages area.
 * 
 * @param {string} username - The sender's username
 * @param {string} content - The decrypted message content
 * @param {string} timestamp - ISO timestamp string
 * @param {string} encrypted - The encrypted version of the message (for display)
 */
function displayMessage(username, content, timestamp, encrypted, messageType='text', fileUrl='', fileName='') {
    const isSent = username === CURRENT_USER;
    
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isSent ? 'message-sent' : 'message-received'}`;
    
    // Format the timestamp
    const formattedTime = formatTimestamp(timestamp);
    
    let mediaHtml = '';
    if (messageType === 'text') {
        mediaHtml = `<div class="message-content">${escapeHtml(content)}</div>`;
    } else if (messageType === 'image') {
        mediaHtml = `<div class="message-media"><img src="${fileUrl}" alt="Image" class="chat-image" onclick="window.open(this.src, '_blank')"></div>`;
    } else if (messageType === 'video') {
        mediaHtml = `<div class="message-media"><video src="${fileUrl}" controls class="chat-video"></video></div>`;
    } else {
        mediaHtml = `<div class="message-file">
            <a href="${fileUrl}" target="_blank" class="file-card">
                <span class="file-icon">📄</span>
                <span class="file-name">${escapeHtml(fileName)}</span>
                <span class="file-download">⬇️</span>
            </a>
        </div>`;
    }
    
    messageDiv.innerHTML = `
        <div class="message-bubble" title="Encrypted: ${escapeHtml(encrypted || 'N/A')}">
            <div class="message-header">
                <span class="message-sender">${escapeHtml(username)}</span>
                <span class="message-time">${formattedTime}</span>
            </div>
            ${mediaHtml}
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    
    // Auto-scroll to the latest message
    scrollToBottom();
}

/**
 * Display a status message (user joined/left).
 * 
 * @param {string} username - The username
 * @param {string} status - 'online' or 'offline'
 */
function displayStatusMessage(username, status) {
    const statusDiv = document.createElement('div');
    statusDiv.className = 'status-message';
    
    const icon = status === 'online' ? '🟢' : '🔴';
    const text = status === 'online' ? 'joined the room' : 'left the room';
    
    statusDiv.innerHTML = `<span>${icon}</span><span>${escapeHtml(username)} ${text}</span>`;
    
    chatMessages.appendChild(statusDiv);
    scrollToBottom();
}


// ═══════════════════════════════════════════
// UI Helpers
// ═══════════════════════════════════════════

/**
 * Update the connection status indicator.
 * 
 * @param {string} status - 'connected', 'disconnected', or default
 * @param {string} text - Status text to display
 */
function updateConnectionStatus(status, text) {
    connectionIndicator.className = `connection-indicator ${status}`;
    connectionStatus.textContent = text;
}

/**
 * Format an ISO timestamp to a human-readable time string.
 * 
 * @param {string} isoString - ISO 8601 timestamp
 * @returns {string} Formatted time (e.g., "3:45 PM")
 */
function formatTimestamp(isoString) {
    try {
        const date = new Date(isoString);
        return date.toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
    } catch (e) {
        return '';
    }
}

/**
 * Escape HTML special characters to prevent XSS.
 * 
 * @param {string} text - Raw text
 * @returns {string} HTML-escaped text
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Scroll the messages container to the bottom.
 */
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}


// ═══════════════════════════════════════════
// Event Listeners
// ═══════════════════════════════════════════

// Send button click
sendBtn.addEventListener('click', sendMessage);

// Enter key to send message
messageInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

// Admin actions
const clearBtn = document.getElementById('clear-chat-btn');
if (clearBtn) {
    clearBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to clear chat history for everyone? This cannot be undone.')) {
            if (chatSocket && chatSocket.readyState === WebSocket.OPEN) {
                chatSocket.send(JSON.stringify({'action': 'clear_chat'}));
            }
        }
    });
}

const deleteBtn = document.getElementById('delete-room-btn');
if (deleteBtn) {
    deleteBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to permanently delete this room and all its history? This cannot be undone.')) {
            if (chatSocket && chatSocket.readyState === WebSocket.OPEN) {
                chatSocket.send(JSON.stringify({'action': 'delete_room'}));
            }
        }
    });
}

// ─── File Upload Logic ───
const attachBtn = document.getElementById('attach-btn');
const fileInput = document.getElementById('file-input');

if (attachBtn && fileInput) {
    attachBtn.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', async function() {
        const file = this.files[0];
        if (!file) return;

        // Visual feedback
        messageInput.placeholder = `Uploading ${file.name}...`;
        attachBtn.disabled = true;

        const formData = new FormData();
        formData.append('file', file);
        // We need CSRF token for Django POST. The simplest way is fetching it from cookies.
        let csrfToken = document.cookie.split('; ').find(row => row.startsWith('csrftoken='))?.split('=')[1];

        try {
            const response = await fetch(`/api/chat/${ROOM_NAME}/upload/`, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': csrfToken
                },
                body: formData
            });

            const data = await response.json();
            if (!response.ok) {
                alert(data.error || 'Upload failed');
            }
            // If successful, the websocket handles injecting it into chat via broadcast!
            
        } catch (error) {
            console.error("Upload error:", error);
            alert("File upload error.");
        } finally {
            // Reset input state
            this.value = '';
            messageInput.placeholder = "Type your encrypted message...";
            attachBtn.disabled = false;
        }
    });
}

// Focus input on page load
messageInput.focus();

// Scroll to bottom on page load (for chat history)
scrollToBottom();


// ═══════════════════════════════════════════
// Initialize Connection
// ═══════════════════════════════════════════
connectWebSocket();
