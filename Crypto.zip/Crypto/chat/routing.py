"""
WebSocket URL routing for the chat application.

Maps WebSocket URLs to consumer classes.
"""

from django.urls import re_path
from . import consumers

# WebSocket URL patterns
websocket_urlpatterns = [
    # ws/chat/<room_name>/ - connects to the ChatConsumer
    re_path(r'ws/chat/(?P<room_name>[^/]+)/$', consumers.ChatConsumer.as_asgi()),
]
