"""
Views for the Secure Chat Application.

Handles user authentication (register, login, logout),
chat lobby (room listing/creation), and chat room display.
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import uuid
import os

from .forms import RegisterForm, ChatRoomForm
from .models import ChatRoom, Message
from .encryption import decrypt_message, encrypt_message


# ──────────────────────────────────────────────
# Authentication and Intro Views
# ──────────────────────────────────────────────

def landing_view(request):
    """
    Display the Hero landing page.
    Redirects to lobby if user is already authenticated.
    """
    if request.user.is_authenticated:
        return redirect('lobby')
    return render(request, 'chat/landing.html')


def register_view(request):
    """
    Handle user registration.
    Creates a new user account and logs them in automatically.
    """
    if request.user.is_authenticated:
        return redirect('lobby')
    
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Auto-login after registration
            login(request, user)
            messages.success(request, f'Welcome, {user.username}! Your account has been created.')
            return redirect('lobby')
    else:
        form = RegisterForm()
    
    return render(request, 'chat/register.html', {'form': form})


def login_view(request):
    """
    Handle user login.
    Authenticates the user and redirects to the chat lobby.
    """
    if request.user.is_authenticated:
        return redirect('lobby')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.username}!')
            return redirect('lobby')
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'chat/login.html')


def logout_view(request):
    """Log the user out and redirect to the login page."""
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('login')


# ──────────────────────────────────────────────
# Chat Views
# ──────────────────────────────────────────────

@login_required
def lobby_view(request):
    """
    Display the chat lobby with all available rooms.
    Users can see existing rooms and create new ones.
    """
    rooms = ChatRoom.objects.all()
    form = ChatRoomForm()
    
    return render(request, 'chat/lobby.html', {
        'rooms': rooms,
        'form': form,
    })


@login_required
def create_room_view(request):
    """
    Handle chat room creation.
    Creates a new room and redirects the user to it.
    """
    if request.method == 'POST':
        form = ChatRoomForm(request.POST)
        if form.is_valid():
            room_name = form.cleaned_data['name']
            description = form.cleaned_data.get('description', '')
            
            # Check if room already exists
            if ChatRoom.objects.filter(name=room_name).exists():
                messages.error(request, 'A room with that name already exists.')
                return redirect('lobby')
            
            # Create the new room
            room = ChatRoom.objects.create(
                name=room_name,
                description=description,
                created_by=request.user,
            )
            messages.success(request, f'Room "{room.name}" created!')
            return redirect('room', room_name=room.name)
    
    return redirect('lobby')


@login_required
def room_view(request, room_name):
    """
    Display a chat room with message history.
    
    Messages are stored encrypted in the database.
    They are decrypted here for display to authenticated users.
    """
    room = get_object_or_404(ChatRoom, name=room_name)
    
    # Get the last 50 messages for this room
    stored_messages = Message.objects.filter(room=room).order_by('-timestamp')[:50]
    # Reverse to show in chronological order
    stored_messages = list(reversed(stored_messages))
    
    # Decrypt messages for display
    aes_key = settings.AES_SECRET_KEY
    chat_messages = []
    for msg in stored_messages:
        decrypted_text = ""
        if msg.message_type == 'text':
            try:
                decrypted_text = decrypt_message(msg.encrypted_content, aes_key)
            except Exception:
                decrypted_text = '[Unable to decrypt message]'
        
        chat_messages.append({
            'sender': msg.sender.username,
            'content': decrypted_text,
            'timestamp': msg.timestamp.isoformat(),
            'message_type': msg.message_type,
            'file_url': msg.file_url or '',
            'file_name': msg.file_name or '',
            'file_size': msg.file_size or 0,
        })
    
    return render(request, 'chat/room.html', {
        'room': room,
        'chat_messages': chat_messages,
    })


# ──────────────────────────────────────────────
# File Upload API
# ──────────────────────────────────────────────

@login_required
def upload_file_view(request, room_name):
    """
    Handle multimedia file uploads (images, videos, documents).
    Saves file to media folder, creates database Message, and broadcasts
    the payload over WebSockets explicitly avoiding huge binary frames.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'POST method required'}, status=405)
        
    file_obj = request.FILES.get('file')
    if not file_obj:
        return JsonResponse({'error': 'No file submitted'}, status=400)
        
    # Security: File Size limit (10MB)
    MAX_FILE_SIZE = 10 * 1024 * 1024
    if file_obj.size > MAX_FILE_SIZE:
        return JsonResponse({'error': 'File exceeds 10MB limit'}, status=400)
        
    # Get extension and categorize type
    ext = os.path.splitext(file_obj.name)[1].lower()
    img_exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp']
    vid_exts = ['.mp4', '.webm']
    doc_exts = ['.pdf', '.doc', '.docx', '.txt', '.zip', '.csv']
    
    if ext in img_exts:
        message_type = 'image'
    elif ext in vid_exts:
        message_type = 'video'
    elif ext in doc_exts:
        message_type = 'document'
    else:
        return JsonResponse({'error': 'Unsupported file type'}, status=400)
        
    try:
        room = ChatRoom.objects.get(name=room_name)
    except ChatRoom.DoesNotExist:
        return JsonResponse({'error': 'Room not found'}, status=404)
        
    # Use FileSystemStorage to save securely
    fs = FileSystemStorage()
    # Generate unique filename to prevent overwrites
    safe_name = f"{uuid.uuid4().hex[:8]}_{file_obj.name.replace(' ', '_')}"
    saved_name = fs.save(f"chat_files/{safe_name}", file_obj)
    file_url = fs.url(saved_name)
    
    # Construct metadata to encrypt so encrypted_content is never NULL
    metadata_string = f"[{message_type.upper()}] URL: {file_url} | Name: {file_obj.name}"
    aes_key = settings.AES_SECRET_KEY
    encrypted_meta = encrypt_message(metadata_string, aes_key)
    
    # Save to database
    msg = Message.objects.create(
        room=room,
        sender=request.user,
        message_type=message_type,
        file_url=file_url,
        file_name=file_obj.name,
        file_size=file_obj.size,
        encrypted_content=encrypted_meta
    )
    
    # Broadcast URL over WebSocket
    channel_layer = get_channel_layer()
    room_group_name = f"chat_{room_name}"
    
    async_to_sync(channel_layer.group_send)(
        room_group_name,
        {
            'type': 'chat_message', # Reusing the default message handler
            'message': '',          # Empty text
            'message_type': message_type,
            'file_url': file_url,
            'file_name': file_obj.name,
            'file_size': file_obj.size,
            'username': request.user.username,
            'timestamp': msg.timestamp.isoformat(),
            'encrypted': ''
        }
    )
    
    return JsonResponse({
        'success': True,
        'message_type': message_type,
        'url': file_url
    })
