"""
Forms for user authentication in the Secure Chat Application.

RegisterForm: Handles new user registration with email.
"""

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class RegisterForm(UserCreationForm):
    """
    Extended user registration form with email field.
    Includes custom widget styling for the modern UI.
    """
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'placeholder': 'Enter your email',
            'class': 'form-input',
        })
    )
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={
                'placeholder': 'Choose a username',
                'class': 'form-input',
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add custom styling to password fields
        self.fields['password1'].widget.attrs.update({
            'placeholder': 'Create a password',
            'class': 'form-input',
        })
        self.fields['password2'].widget.attrs.update({
            'placeholder': 'Confirm your password',
            'class': 'form-input',
        })


class ChatRoomForm(forms.Form):
    """Form for creating a new chat room."""
    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'placeholder': 'Enter room name',
            'class': 'form-input',
        })
    )
    description = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'placeholder': 'Room description (optional)',
            'class': 'form-input',
        })
    )
