"""
AES Encryption Module for Secure Chat Application.

Uses AES-256-CBC encryption with:
- A fixed 32-byte shared secret key
- A random 16-byte Initialization Vector (IV) per message
- PKCS7 padding for block alignment

The IV is prepended to the ciphertext and the result is base64-encoded
for safe storage in the database.
"""

import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes


def encrypt_message(message, key):
    """
    Encrypt a plaintext message using AES-256-CBC.
    
    Args:
        message (str): The plaintext message to encrypt.
        key (bytes): A 32-byte secret key for AES-256.
    
    Returns:
        str: Base64-encoded string containing IV + ciphertext.
    
    Example:
        >>> key = b'ThisIsA32ByteSecretKeyForAES!!'
        >>> encrypted = encrypt_message("Hello, World!", key)
        >>> print(encrypted)  # Base64 encoded string
    """
    # Generate a random 16-byte IV for this message
    iv = get_random_bytes(16)
    
    # Create AES cipher in CBC mode with the IV
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    # Pad the message to be a multiple of 16 bytes (AES block size)
    padded_message = pad(message.encode('utf-8'), AES.block_size)
    
    # Encrypt the padded message
    ciphertext = cipher.encrypt(padded_message)
    
    # Prepend IV to ciphertext and encode as base64 for safe storage
    encrypted_data = base64.b64encode(iv + ciphertext).decode('utf-8')
    
    return encrypted_data


def decrypt_message(encrypted_data, key):
    """
    Decrypt an AES-256-CBC encrypted message.
    
    Args:
        encrypted_data (str): Base64-encoded string containing IV + ciphertext.
        key (bytes): The same 32-byte secret key used for encryption.
    
    Returns:
        str: The original plaintext message.
    
    Example:
        >>> key = b'ThisIsA32ByteSecretKeyForAES!!'
        >>> decrypted = decrypt_message(encrypted, key)
        >>> print(decrypted)  # "Hello, World!"
    """
    # Decode the base64-encoded data
    raw_data = base64.b64decode(encrypted_data)
    
    # Extract the IV (first 16 bytes) and ciphertext (remaining bytes)
    iv = raw_data[:16]
    ciphertext = raw_data[16:]
    
    # Create AES cipher in CBC mode with the extracted IV
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    # Decrypt and remove padding
    decrypted_message = unpad(cipher.decrypt(ciphertext), AES.block_size)
    
    return decrypted_message.decode('utf-8')
