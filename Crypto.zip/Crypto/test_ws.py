import asyncio
import os
import django
from channels.testing import WebsocketCommunicator

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "securechat.settings")
django.setup()

from securechat.asgi import application
from django.contrib.auth.models import User
from chat.models import ChatRoom

async def test():
    # Make sure we have a user and room
    user, _ = await asyncio.to_thread(User.objects.get_or_create, username="testuser")
    room, _ = await asyncio.to_thread(ChatRoom.objects.get_or_create, name="Crypto", defaults={"created_by": user})
    
    communicator = WebsocketCommunicator(application, '/ws/chat/Crypto/')
    # Force authenticated user scope
    communicator.scope['user'] = user
    
    connected, _ = await communicator.connect()
    print("Connected:", connected)
    
    print("Pre-Send:", await communicator.receive_from())
    
    # Send a message
    await communicator.send_json_to({'message': 'hiii'})
    
    # Receive response (should be broadcasted message or error)
    response = await communicator.receive_from(timeout=5)
    print("Response 1:", response)
    
    await communicator.disconnect()

asyncio.run(test())
