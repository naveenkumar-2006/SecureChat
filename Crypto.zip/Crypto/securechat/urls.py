"""
URL configuration for securechat project.
Routes to Django admin and chat app URLs.
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('chat.urls')),  # All chat URLs at root
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
