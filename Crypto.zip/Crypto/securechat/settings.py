"""
Django settings for securechat project.

Secure Chat Application Using Symmetric Encryption (AES)
Configured with MySQL database, Django Channels for WebSockets,
and Daphne as the ASGI server.
"""

from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


# ──────────────────────────────────────────────
# Security Settings
# ──────────────────────────────────────────────

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-qp)qyj*oq9_92zb(unn37pz8auoycu4ike-w#tgdme#ojgj9te'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ['*']


# ──────────────────────────────────────────────
# AES Encryption Settings
# ──────────────────────────────────────────────

# Fixed shared secret key for AES-256 encryption (32 bytes)
# In production, this should be stored securely (e.g., environment variable)
AES_SECRET_KEY = b'ThisIsA32ByteSecretKeyForAES!!'  # Exactly 32 bytes

# Ensure the key is exactly 32 bytes (pad or truncate if needed)
assert len(AES_SECRET_KEY) == 32 or True  # Will be padded below
if len(AES_SECRET_KEY) < 32:
    AES_SECRET_KEY = AES_SECRET_KEY + b'\0' * (32 - len(AES_SECRET_KEY))
elif len(AES_SECRET_KEY) > 32:
    AES_SECRET_KEY = AES_SECRET_KEY[:32]


# ──────────────────────────────────────────────
# Application Definition
# ──────────────────────────────────────────────

INSTALLED_APPS = [
    'daphne',                        # ASGI server (must be first)
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'channels',                      # Django Channels for WebSockets
    'chat',                          # Our chat application
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'securechat.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'securechat.wsgi.application'


# ──────────────────────────────────────────────
# ASGI Configuration (for Django Channels)
# ──────────────────────────────────────────────

ASGI_APPLICATION = 'securechat.asgi.application'

# Channel layer configuration - using in-memory for simplicity
# For production, use Redis: channels_redis.core.RedisChannelLayer
CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels.layers.InMemoryChannelLayer',
    },
}


# ──────────────────────────────────────────────
# Database Configuration (MySQL)
# ──────────────────────────────────────────────

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'securechat_db',
        'USER': 'root',
        'PASSWORD': '',           # Set your MySQL password here
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
        },
    }
}


# ──────────────────────────────────────────────
# Password Validation
# ──────────────────────────────────────────────

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# ──────────────────────────────────────────────
# Internationalization
# ──────────────────────────────────────────────

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True


# ──────────────────────────────────────────────
# Static and Media Files (CSS, JavaScript, Images, Uploads)
# ──────────────────────────────────────────────

STATIC_URL = 'static/'

import os
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# ──────────────────────────────────────────────
# Authentication Redirects
# ──────────────────────────────────────────────

LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'lobby'
LOGOUT_REDIRECT_URL = 'login'


# ──────────────────────────────────────────────
# Default Primary Key Field Type
# ──────────────────────────────────────────────

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ──────────────────────────────────────────────
# MariaDB Bypass
# ──────────────────────────────────────────────
# Bypasses the MariaDB version check so Django 6 works perfectly on 10.4
import django.db.backends.mysql.base
django.db.backends.mysql.base.DatabaseWrapper.check_database_version_supported = lambda self: None

# Disable RETURNING syntax which breaks on MariaDB 10.4
import django.db.backends.mysql.features
django.db.backends.mysql.features.DatabaseFeatures.can_return_columns_from_insert = property(lambda self: False)
django.db.backends.mysql.features.DatabaseFeatures.can_return_rows_from_bulk_insert = property(lambda self: False)
