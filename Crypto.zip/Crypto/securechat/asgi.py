"""
ASGI config for securechat project.

Configures HTTP and WebSocket routing with authentication middleware.
WebSocket connections are authenticated using Django's session auth.
"""

import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'securechat.settings')

# Initialize Django ASGI application early to ensure apps are loaded
django_asgi_app = get_asgi_application()

# Import chat routing after Django setup
from chat.routing import websocket_urlpatterns

# Main ASGI application that routes HTTP and WebSocket connections
application = ProtocolTypeRouter({
    # HTTP requests are handled by Django's standard ASGI handler
    'http': django_asgi_app,
    
    # WebSocket connections go through auth middleware then to our URL router
    'websocket': AuthMiddlewareStack(
        URLRouter(websocket_urlpatterns)
    ),
})
