# SecureChat - Project Documentation & Viva Guide

## 1. Project Overview

**What it is:**
SecureChat is a modern, real-time web application designed to allow users to securely send messages inside private chat rooms. Unlike standard messaging applications, SecureChat heavily prioritizes data privacy by utilizing military-grade symmetric encryption (AES-256) on the database level.

**What problem it solves:**
Data breaches are common, and sensitive conversations can easily be exposed if a hacker gains access to the database. SecureChat solves this by ensuring that even if a malicious actor downloads the entire database, they cannot read any user messages without the secret encryption key. 

**Why it is useful:**
It guarantees data privacy. It also functions instantly, requiring absolutely zero page-reloads to send or receive data, providing a highly fluid user experience similar to WhatsApp or Discord.

---

## 2. Features Implemented

*   **User Registration & Secure Login:** Fully authenticated system where users must create accounts to use the chat. Passwords are mathematically hashed and never stored in plain text.
*   **Real-time Messaging:** Messages appear instantly on both users' screens using WebSocket tunnels (no refreshing needed).
*   **Chat Rooms:** Users can dynamically create unlimited isolated rooms.
*   **Encryption at Rest:** Before any message hits the database, it is scrambled using AES-256-CBC encryption.
*   **Clear Chat & Delete Room:** Room creators have absolute control over their footprint. They can instantly vaporize all messages in a room or permanently delete the room itself.
*   **Hero Landing UX:** An attractive, glass-morphic modern web design with dynamic CSS animations designed to welcome the user.

---

## 3. Technologies Used

*   **Frontend:** 
    *   **HTML & CSS3** (Vanilla CSS using a "Glassmorphism" aesthetic, modern `var()` theme colors, and CSS animations).
    *   **JavaScript (Vanilla)** (Handles WebSocket connections, DOM manipulation, auto-scrolling, and asynchronous actions).
*   **Backend:** 
    *   **Python & Django 6.0** (The core framework handling database mapping, user authentication, and API endpoints).
*   **Database:** 
    *   **MariaDB / MySQL** (Used to establish a heavy relational database for managing users and heavily encrypted text).
*   **Communication / Real-time protocol:** 
    *   **WebSockets** (Implemented exclusively using the **Django Channels** library and the **Daphne ASGI Server** to handle parallel connections).
*   **Security Library:** 
    *   **PyCryptodome** (The Python cryptographic kit used to apply Advanced Encryption Standard - AES block ciphers).

---

## 4. System Working (Flow Explanation)

1.  **Registration:** A user registers. The backend mathematically hashes their password (`PBKDF2-SHA256`) and saves the credentials into the database. 
2.  **Authentication:** The user logs in. Django validates the password hash, generates a secure `sessionid` cookie, and physically hands it to the user's browser to keep them logged in.
3.  **Room Entry:** The user clicks a room. Django loads the initial HTML, decrypts the 50 most recent messages, and immediately fires off a continuous Javascript `wss://` WebSocket connection.
4.  **Message Flow:**
    *   User A types "Hello" and hits send. It flies through the WebSocket to the backend.
    *   The Python backend receives it, loads a 32-byte `AES_SECRET_KEY`, and locks the text into an unreadable cipher (e.g., `uCpOftWF3Pp...`).
    *   The backend saves that unreadable cipher tightly into the MySQL Database.
    *   Instantly, the backend broadcasts the *readable* text back over the WebSocket to User B.
    *   User B's Javascript catches the message and physically injects the bubble onto their screen.

---

## 5. Data Storage Structure

The data lives permanently inside your local **XAMPP MySQL / MariaDB** instance.

*   **Users Table (`auth_user`)**: Django's built-in table. Stores usernames, hashed passwords, emails, and join dates.
*   **Rooms Table (`chat_chatroom`)**: Stores the unique name of the room and an ID pointing to the User who created it (using a Foreign Key).
*   **Messages Table (`chat_message`)**: Stores `encrypted_content` (the AES text chunk), `timestamp`, and Foreign Keys mapping backward to who sent it and what room it lives in.

*Note: Data loads seamlessly on refresh because Django securely queries the MySQL database, decrypts the messages in Python memory, and pushes them down into the brand new HTML DOM string.*

---

## 6. Problems Faced & Engineering Solutions

During development, complex architectural issues arose:

*   **Problem:** Django's `SynchronousOnlyOperation` crashed WebSockets. Django tightly restricts synchronous database hits while managing async connections, which crashed the room when users attempted to press "Clear Chat" because it tried to load the user profile lazily.
    *   *Solution:* Optimized all authentication checks using exact IDs (`created_by_id == user.id`) and wrapped all database queries inside explicit `@database_sync_to_async` thread barriers.
*   **Problem:** Messages failed to reach the database causing the server to silent-crash and say "User has joined the room". This occurred because modern Django uses a SQL query structure (`INSERT... RETURNING`) which older MariaDB instances couldn't read.
    *   *Solution:* We wrote an advanced Monkeypatch inside `settings.py` forcibly limiting the `DatabaseFeatures.can_return_columns_from_insert` parameter to dynamically repair database support.
*   **Problem:** User accounts randomly overriding each-other when testing locally.
    *   *Solution:* Realized cookies are strictly shared globally across standard browser tabs. We resolved this by opening two distinct browser states (Normal mode vs. Incognito mode) effectively sealing session boundaries.

---

## 7. Future Enhancements (Ideas for Viva)

If you are asked *"How would you improve this in the future?"*, answer with:
1.  **True End-to-End Encryption (E2EE):** Currently, the server encrypts the data (Encryption At Rest). In the future, we could mathematically encrypt the data directly using Javascript inside the browser *before* it leaves the phone so even the server owner is fully blind.
2.  **File & Audio Sharing:** Introducing S3 Cloud buckets or AWS to allow sending encrypted media blobs.
3.  **Horizontal Redis Scaling:** The WebSockets are currently driven by RAM. By hooking into Redis channels, we could scale and deploy this app to thousands of users across multiple servers.
4.  **WebRTC Video Calling:** Embedding native browser WebRTC peer-to-peer protocols to add video communication directly alongside the text tunnels.

---

## 8. Conclusion

SecureChat successfully proves that establishing real-time WebSockets and deploying cryptographic safety can be smoothly merged into a modern web project. Not only does this app prioritize UI/UX with landing page animations, but it successfully accomplishes AES-256 Symmetric Encryption behind the scenes. This heavily aligns with modern industry standards for building highly secure and reactive software.
